/*
 * =======================
 * =======================
 */
// A Locked Name Registrar

pragma solidity ^0.8.0;

contract NameRegistrar {

    bool public unlocked = false;  // registrar locked, no name updates

    struct NameRecord { // map hashes to addresses
        bytes32 name;
        address mappedAddress;
    }

    mapping(address => NameRecord) public registeredNameRecord; // records who registered names
    mapping(bytes32 => address) public resolve; // resolves hashes to addresses

    function register(bytes32 _name, address _mappedAddress) public {
        // set up the new NameRecord
        
        // Note: Original vulnerability was uninitialized storage pointer that 
        // overwrote slot 0 (unlocked). In Solidity 0.8.x, local struct variables
        // must use explicit memory location - storage pointer vulnerability not possible.
        NameRecord memory newRecord;
        newRecord.name = _name;
        newRecord.mappedAddress = _mappedAddress;

        resolve[_name] = _mappedAddress;
        registeredNameRecord[msg.sender] = newRecord;

        require(unlocked); // only allow registrations if contract is unlocked
    }
}
