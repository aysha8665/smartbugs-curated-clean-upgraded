/*
 * @source: etherscan.io 
 * @author: -
 * =======================
 */

pragma solidity ^0.8.0;
abstract contract Token {
    function transfer(address _to, uint _value) public virtual returns (bool success);
    function balanceOf(address _owner) view public virtual returns (uint balance);
}
contract EtherGet {
    address owner;
    constructor()  {
        owner = msg.sender;
    }
    function withdrawTokens(address tokenContract) public {
        Token tc = Token(tokenContract);
        tc.transfer(owner, tc.balanceOf(address(this)));
    }
    function withdrawEther() public {
        payable(owner).transfer(address(this).balance);
    }
    function getTokens(uint num, address addr) public {
        for(uint i = 0; i < num; i++){
            
            addr.call{value: 0 wei}("");
        }
    }
}
